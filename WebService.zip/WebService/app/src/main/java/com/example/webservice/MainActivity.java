package com.example.webservice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        private EditText entrada;
        private TextView saida;
        private Button enviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        entrada = (EditText) findViewById(R.id.entrada);
        saida = (TextView) findViewById(R.id.saida);
        enviar = (Button) findViewById(R.id.enviar);
        enviar.setOnClickListener((View.OnClickListener) this);

    }

    public void OnClick(View v) {
        if(v.getId()==R.id.enviar){
            String url = "https://swapi.dev/api/people/"+entrada.getText().toString().trim();
            //Conexão com INTERNET

        }

    }

}